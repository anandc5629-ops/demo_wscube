# 4. Multiply Two Numbers
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
print("Product =", a * b)
