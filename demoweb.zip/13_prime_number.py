# 13. Check Prime Number
number = int(input("Enter an integer: "))
if number < 2:
    print("Not a prime number")
else:
    is_prime = True
    for i in range(2, int(number ** 0.5) + 1):
        if number % i == 0:
            is_prime = False
            break
    print("Prime number" if is_prime else "Not a prime number")
