# 15. Reverse a String
text = input("Enter a word or sentence: ")
print("Reversed =", text[::-1])
