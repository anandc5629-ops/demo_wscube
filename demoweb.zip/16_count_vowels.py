# 16. Count Vowels in a String
text = input("Enter a sentence: ")
count = sum(1 for char in text.lower() if char in "aeiou")
print("Number of vowels =", count)
