# 18. Calculate Area of a Circle
radius = float(input("Enter radius: "))
if radius >= 0:
    area = 3.14159 * radius * radius
    print("Area =", area)
else:
    print("Radius cannot be negative.")
