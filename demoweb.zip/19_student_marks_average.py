# 19. Calculate Student Total and Average
marks = []
for i in range(1, 6):
    mark = float(input(f"Enter marks for subject {i}: "))
    marks.append(mark)

total = sum(marks)
average = total / len(marks)
print("Total marks =", total)
print("Average marks =", average)
